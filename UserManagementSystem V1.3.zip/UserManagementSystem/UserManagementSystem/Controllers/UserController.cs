﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UserManagementSystem.Models;

namespace UserManagementSystem.Controllers
{
    public class UserController : Controller
    {
        public readonly IConfiguration _configuration;
        public readonly string _webApiUrl;

        public UserController(IConfiguration configuration)
        {
            _configuration = configuration;
            _webApiUrl = _configuration.GetValue<string>("WebApiUrl");
        }

        public ActionResult UserRegister()
        {
            return View();
        }

        //new Registraion or add new User
        [HttpPost]
        public async Task<ActionResult> Register(UserViewModel userViewmodel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Clear();
                        client.DefaultRequestHeaders.ConnectionClose = true;

                        //passing data to service using Http Content
                        StringContent content = new StringContent(JsonConvert.SerializeObject(userViewmodel), UnicodeEncoding.UTF8, "application/json");

                        using (var resource = await client.PostAsync(_webApiUrl + "User", content))
                        {
                            if (resource.IsSuccessStatusCode)
                            {
                                string result = resource.Content.ReadAsStringAsync().Result;
                                if (result == "1" && HttpContext.Session.GetString("UserName") == null)
                                {
                                    return RedirectToAction("Login", "Account");
                                }
                                else if (result == "1" && HttpContext.Session.GetString("UserName") != null)
                                {
                                    TempData["Result"] = 1;
                                    return RedirectToAction("UserDetails");
                                }
                                else if (result == "2")
                                {
                                    ModelState.AddModelError(string.Empty, "UserName Alredy Existed");
                                }


                            }
                        }
                    }

                }
                else
                {
                    ModelState.AddModelError(string.Empty, "In valid Data");
                }
            }
            catch (Exception)
            {
                ModelState.AddModelError(string.Empty, "In valid Data");
                return View("UserRegister", userViewmodel);
                throw;
            }

            return View("UserRegister", userViewmodel);
        }

        //retriving  the all User Details
        [HttpGet]
        public async Task<ActionResult> UserDetails()
        {
            var a = HttpContext.Session.GetString("UserName");
            if (HttpContext.Session.GetString("UserName") == null)
                return RedirectToAction("Login", "Account");


            UserViewModel userViewModel = new UserViewModel();
            ViewBag.Message = GetMessagedata(Convert.ToInt32(TempData["Result"]));
            try
            {
                if (ModelState.IsValid)
                {
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Clear();
                        client.DefaultRequestHeaders.ConnectionClose = true;
                        using (var resource = await client.GetAsync(_webApiUrl + "User"))
                        {
                            if (resource.IsSuccessStatusCode)
                            {

                                List<UserViewModel> list = JsonConvert.DeserializeObject<List<UserViewModel>>(resource.Content.ReadAsStringAsync().Result);
                                userViewModel.EmployeList = list;
                                return View(userViewModel);
                            }
                        }
                    }

                }
                else
                {
                    ModelState.AddModelError(string.Empty, "In valid Data");
                }
            }
            catch (Exception)
            {

                throw;
            }

            return View();

        }
        //Retrvining the user details based on id
        [HttpGet]
        public async Task<ActionResult> GetUserInformation(int id)
        {

            try
            {
                if (ModelState.IsValid)
                {
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Clear();
                        client.DefaultRequestHeaders.ConnectionClose = true;
                        var url = _webApiUrl + "UserAPI?id=" + id;
                        using (var resource = await client.GetAsync(url))
                        {
                            if (resource.IsSuccessStatusCode)
                            {
                                UserViewModel model = JsonConvert.DeserializeObject<UserViewModel>(resource.Content.ReadAsStringAsync().Result);
                                return View("UserInformation", model);
                            }
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "In valid Data");
                }
            }
            catch (Exception)
            {

                throw;
            }

            return View();
        }

        //load view  the user details
        [HttpGet]
        public ActionResult UserInformation(UserViewModel userViewmodel)
        {
            return View(userViewmodel);
        }

        //update user information
        [HttpPost]
        public async Task<ActionResult> UpdateUser(UserViewModel userViewmodel)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Clear();
                        client.DefaultRequestHeaders.ConnectionClose = true;

                        //passing data to service using Http Content
                        StringContent content = new StringContent(JsonConvert.SerializeObject(userViewmodel), UnicodeEncoding.UTF8, "application/json");

                        using (var resource = await client.PostAsync(_webApiUrl + "UserAPI", content))
                        {
                            if (resource.IsSuccessStatusCode)
                            {
                                TempData["Result"] = 2;
                                return RedirectToAction("UserDetails");
                            }
                        }
                    }

                }
                else
                {
                    ModelState.AddModelError(string.Empty, "In valid Data");
                }
            }
            catch (Exception)
            {
                ModelState.AddModelError(string.Empty, "Contact to Techincal Team ");
                throw;
            }

            return View("UserInformation", userViewmodel);
        }

        //delete  the user record 
        [HttpGet]
        public async Task<ActionResult> UserDelete(int id)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.ConnectionClose = true;
                    var url = _webApiUrl + "User?id=" + id;
                    using (var resource = await client.DeleteAsync(url))
                    {
                        if (resource.IsSuccessStatusCode)
                        {
                            TempData["Result"] = 3;
                            return RedirectToAction("UserDetails");
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return RedirectToAction("UserDetails");
        }

        public string GetMessagedata(int id)
        {
            string Message = "";
            switch (id)
            {
                case 1:
                    Message = "Record Added Successfully";
                    break;
                case 2:
                    Message = "Record Updated Successfully";
                    break;
                case 3:
                    Message = "Record Deleted Successfully";
                    break;


            }
            return Message;
        }


    }
}
