﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.Models;

namespace UserService.Repository
{
   public interface IUserRepository
    {
        List<User> GetUserDetails();
        User GetUserInformation(int UserID);
        int Adduser(User user);

        void UpdateUser(User user);

        void DeleteUser(int UserID);

    }
}
