﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.EntityFramework;
using UserService.Models;

namespace UserService.Repository
{
    public class UserRepository : IUserRepository
    {
        private AppDBContext _appDBContext;
        public UserRepository(AppDBContext appDBContext)
        {
            _appDBContext = appDBContext;
        }
        public int Adduser(User user)
        {
            if (_appDBContext.User.Any(a => a.UserName.ToLower().Trim() == user.UserName.ToLower().Trim()))
                return 2;

            User Userinfo = new User();
            Userinfo.FirstName = user.FirstName;
            Userinfo.LastName = user.LastName;
            Userinfo.Email = user.Email;
            Userinfo.Mobile = user.Mobile;
            Userinfo.Address = user.Address;
            Userinfo.Gender = user.Gender;
            Userinfo.City = user.City;
            Userinfo.State = user.State;
            Userinfo.Country = user.Country;
            Userinfo.PinCode = user.PinCode;
            Userinfo.UserName = user.UserName;
            Userinfo.Password = user.Password;
            Userinfo.IsAdmin = user.IsAdmin;
            _appDBContext.User.Add(Userinfo);
            _appDBContext.SaveChanges();
            return 1;
        }
        public void DeleteUser(int UserID)
        {
            _appDBContext.User.Remove(_appDBContext.User.SingleOrDefault(a => a.UserId == UserID));
            _appDBContext.SaveChangesAsync();
        }

        public List<User> GetUserDetails()
        {
            return _appDBContext.User.ToList();
        }

        public User GetUserInformation(int UserID)
        {
            return _appDBContext.User.SingleOrDefault(a => a.UserId == UserID);
        }

        public void UpdateUser(User user)
        {
            var Userinfo = _appDBContext.User.SingleOrDefault(a => a.UserId == user.UserId);
            Userinfo.FirstName = user.FirstName;
            Userinfo.LastName = user.LastName;
            Userinfo.Email = user.Email;
            Userinfo.Mobile = user.Mobile;
            Userinfo.Address = user.Address;
            Userinfo.Gender = user.Gender;
            Userinfo.City = user.City;
            Userinfo.State = user.State;
            Userinfo.Country = user.Country;
            Userinfo.PinCode = user.PinCode;
            Userinfo.UserName = user.UserName;
            Userinfo.Password = user.Password;
            Userinfo.IsAdmin = user.IsAdmin;
            _appDBContext.SaveChangesAsync();

        }
    }
}
