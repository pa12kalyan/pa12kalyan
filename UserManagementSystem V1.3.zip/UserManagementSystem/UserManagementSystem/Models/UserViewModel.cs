﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace UserManagementSystem.Models
{
    public class UserViewModel
    {

        public int UserId { get; set; }
        [Required(ErrorMessage = "Please Enter FirstName")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please Enter LastName")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Please Enter Email")]
        public string Email { get; set; }

        [Display(Name = "Mobile Number:")]
        [Required(ErrorMessage = "Please Enter Mobile")]
        public int Mobile { get; set; }
        [Required(ErrorMessage = "Please Enter Address")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Please Enter Gender")]
        public bool Gender { get; set; }
        [Required(ErrorMessage = "Please Enter City")]
        public string City { get; set; }
        [Required(ErrorMessage = "Please Enter State")]
        public string State { get; set; }
        [Required(ErrorMessage = "Please Enter Country")]
        public string Country { get; set; }
        [Required(ErrorMessage = "Please Enter PinCode")]
        public int PinCode { get; set; }
        [Required(ErrorMessage = "Please Enter UserName")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Please Enter Password")]
        public string Password { get; set; }
        public bool IsAdmin { get; set; }

        public List<UserViewModel> EmployeList { get; set; }

    }

  public  class UserloginViewModel
    {
        public int UserID { get; set; }
        [Required(ErrorMessage = "Please enter UserName")]
        public string UserName { get; set; }
        [Required(ErrorMessage = "Please enter Password")]
        public string Password { get; set; }
        public bool IsAdmin { get; set; }

    }
    public class Gender
    {
        public bool GenderID { get; set; }
        public string GenderName { get; set; }
        public bool Seleted { get; set; }
    }

}
