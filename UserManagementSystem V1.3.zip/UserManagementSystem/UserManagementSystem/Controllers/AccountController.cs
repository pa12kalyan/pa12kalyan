﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using UserManagementSystem.Models;

namespace UserManagementSystem.Controllers
{
    //[Authorize]
    public class AccountController : Controller
    {

        public readonly IConfiguration _configuration;
        public readonly string _webApiUrl;
        public AccountController(IConfiguration configuration)
        {
            _configuration = configuration;
            _webApiUrl = _configuration.GetValue<string>("WebApiUrl");
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        // [AllowAnonymous]
        public async Task<ActionResult> Userlogin(UserloginViewModel model)
        {
            try
            {
                if (model.UserName != null && model.Password != null)
                {
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Clear();
                        client.DefaultRequestHeaders.ConnectionClose = true;

                        //passing data to service using Http Content
                        StringContent content = new StringContent(JsonConvert.SerializeObject(model), UnicodeEncoding.UTF8, "application/json");

                        using (var resource = await client.PostAsync(_webApiUrl + "UserAccountAPI", content))
                        {
                            if (resource.IsSuccessStatusCode)
                            {
                                UserViewModel list = JsonConvert.DeserializeObject<UserViewModel>(resource.Content.ReadAsStringAsync().Result);

                                if (list != null)
                                {
                                    HttpContext.Session.SetString("IsAdmin", list.IsAdmin.ToString());
                                    HttpContext.Session.SetString("UserName", list.UserName);
                                    return RedirectToAction("UserDetails", "User");
                                }
                            }
                            else
                            {
                                ModelState.AddModelError(string.Empty, "Please Enter valid Data");
                            }
                        }

                    }

                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Please Enter User Name & Password");
                }
            }
            catch (Exception)
            {

                throw;
            }

            return View("Login", model);
        }

        public ActionResult LogOut()
        {
            HttpContext.Session.Clear();
            return View("Login");
        }



    }
}