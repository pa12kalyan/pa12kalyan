﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.Models;
using UserService.Repository;

namespace UserService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserAPIController : ControllerBase
    {
        private IUserRepository _userRepository;
        public UserAPIController(IUserRepository userRepository)
        {

            _userRepository = userRepository;
        }

        [HttpGet]
        public IActionResult GetUserInformation(int id)
        {
            return Ok(_userRepository.GetUserInformation(id));
        }


        [HttpPost]
        public IActionResult UpdateUser(User user)
        {
            _userRepository.UpdateUser(user);
            return Ok(Response.StatusCode);
        }
    }
}
