﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.EntityFramework;
using UserService.Models;

namespace UserService.Repository
{
    public class UserAccountRepositiory : IUserAccountRepositiory
    {
        private AppDBContext _appDBContext;
        public UserAccountRepositiory(AppDBContext appDBContext)
        {
            _appDBContext = appDBContext;
        }
        public User IsUserValidation(User user)
        {
            var info = _appDBContext.User.Where(a => a.UserName.Trim().ToLower() == user.UserName.Trim().ToLower() && a.Password.Trim().ToLower() == user.Password.Trim().ToLower()).SingleOrDefault();
            return info;
           

        }
    }
}
