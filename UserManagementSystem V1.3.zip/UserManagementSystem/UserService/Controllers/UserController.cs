﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.Models;
using UserService.Repository;

namespace UserService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {

        private IUserRepository _userRepository;
        public UserController(IUserRepository userRepository)
        {

            _userRepository = userRepository;
        }
        [HttpGet]
        public IActionResult GetUserDetils()
        {
            return Ok(_userRepository.GetUserDetails());
        }
        
        [HttpPost]
        public IActionResult AddUser(User user)
        {
            return Ok(_userRepository.Adduser(user));
        }


        [HttpDelete]
        public IActionResult DeleteUser(int id)
        {
            _userRepository.DeleteUser(id);
            return Ok(Response.StatusCode);
        }
    }
}
