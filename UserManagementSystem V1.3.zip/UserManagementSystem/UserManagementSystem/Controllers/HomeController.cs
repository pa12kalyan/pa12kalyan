﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using UserManagementSystem.Models;

namespace UserManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public readonly IConfiguration _configuration;
        public readonly string _webApiUrl;

        public HomeController(ILogger<HomeController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
            _webApiUrl = _configuration.GetValue<string>("WebApiUrl");
        }


        

        public IActionResult Index()
        {
            return View();
        }



        public async Task<IActionResult> Privacy()
        {
           await GetUser(1);
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpGet]
        public async Task<ActionResult> GetUser(int id)
        { 
            var client = new HttpClient();
            if (id == 0)
            {
                using (var resource = await client.GetAsync(_webApiUrl + "User"))
                {
                    if (resource.IsSuccessStatusCode)
                    {

                        return View();
                    }
                }
            }
            else if (id == 1)
            {

                using (var resource = await client.GetAsync(_webApiUrl + "UserAPI/GetUserinfo?id="+id))
                {
                    if (resource.IsSuccessStatusCode)
                    {

                        return View();
                    }
                }
            }
            else if (id == 2)
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(id), UnicodeEncoding.UTF8, "application/json");

                using (var resource = await client.PostAsync(_webApiUrl + "UserAPI/Createuser", content))
                {
                    if (resource.IsSuccessStatusCode)
                    {

                        return View();
                    }
                }

            }
            else if (id == 3)
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(id), UnicodeEncoding.UTF8, "application/json");

                using (var resource = await client.PostAsync(_webApiUrl + "UserAPI/Registeruserr", content))
                {
                    if (resource.IsSuccessStatusCode)
                    {

                        return View();
                    }
                }

            }
            else if (id == 4)
            {
                using (var resource = await client.GetAsync(_webApiUrl + "UserAPI"))
                {
                    if (resource.IsSuccessStatusCode)
                    {

                        return View();
                    }
                }
            }
            else if (id == 5)
            {
                using (var resource = await client.GetAsync(_webApiUrl + "UserAPI"))
                {
                    if (resource.IsSuccessStatusCode)
                    {

                        return View();
                    }
                }

            }
            else if (id == 6)
            {
                using (var resource = await client.GetAsync(_webApiUrl + "User"))
                {
                    if (resource.IsSuccessStatusCode)
                    {

                        return View();
                    }
                }
            }
            

            return Ok();
        }
        
    }
}
