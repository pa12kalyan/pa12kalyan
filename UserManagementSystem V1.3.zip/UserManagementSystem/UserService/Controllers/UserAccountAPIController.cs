﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserService.Models;
using UserService.Repository;

namespace UserService.Controllers
{
    [EnableCors("AllowOrigin")]
    [Route("api/[controller]")]
    [ApiController]
    public class UserAccountAPIController : ControllerBase
    {

        private IUserAccountRepositiory  _userAccountRepositiory;
        public UserAccountAPIController(IUserAccountRepositiory userAccountRepositiory)
        {
            _userAccountRepositiory = userAccountRepositiory;
        }
        [HttpGet]
        public string test()
        {
            return "test service";
        }

        [HttpPost]
        public IActionResult LoginValidation(User user)
        {
            var info = _userAccountRepositiory.IsUserValidation(user);
            if (info != null)
                return Ok(info);
            else
                return BadRequest();

        }

        

    }
}
